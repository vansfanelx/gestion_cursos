import { Component } from '@angular/core';

@Component({
  selector: 'app-order-details-table',
  imports: [],
  templateUrl: './order-details-table.component.html',
  styles: ``
})
export class OrderDetailsTableComponent {

}
