import { Component } from '@angular/core';

@Component({
  selector: 'app-four-isto-three',
  imports: [],
  templateUrl: './four-isto-three.component.html',
  styles: ``
})
export class FourIstoThreeComponent {

}
