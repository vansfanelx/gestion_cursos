import { Component } from '@angular/core';

@Component({
  selector: 'app-responsive-image',
  imports: [],
  templateUrl: './responsive-image.component.html',
  styles: ``
})
export class ResponsiveImageComponent {

}
