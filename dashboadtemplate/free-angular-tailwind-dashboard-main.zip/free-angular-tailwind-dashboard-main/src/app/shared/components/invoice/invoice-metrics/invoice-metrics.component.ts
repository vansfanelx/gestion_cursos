import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-invoice-metrics',
  imports: [
    RouterModule,
  ],
  templateUrl: './invoice-metrics.component.html',
  styles: ``
})
export class InvoiceMetricsComponent {

}
