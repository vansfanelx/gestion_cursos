import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-method',
  imports: [],
  templateUrl: './payment-method.component.html',
  styles: ``
})
export class PaymentMethodComponent {

}
