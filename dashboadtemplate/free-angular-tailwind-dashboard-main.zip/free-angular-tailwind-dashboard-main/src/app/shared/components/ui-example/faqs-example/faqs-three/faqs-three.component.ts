import { Component } from '@angular/core';

@Component({
  selector: 'app-faqs-three',
  imports: [],
  templateUrl: './faqs-three.component.html',
  styles: ``
})
export class FaqsThreeComponent {

}
